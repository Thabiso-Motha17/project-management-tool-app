import React from 'react';
import { useSelector } from 'react-redux';
import type{ RootState } from '../../store/store';
import AdminTaskPage from './AdminTaskPage';
import DeveloperTaskPage from './DeveloperTaskPage';
import ClientTaskPage from './ClientTaskPage';
import './TaskManagement.css';
import PageNotFound from '../Pages/PageNotFound';

const TaskManagement: React.FC = () => {
  const { user } = useSelector((state: RootState) => state.auth);

  const renderTaskPage = () => {
    switch (user?.role) {
      case 'manager':
        return <AdminTaskPage />;
      case 'admin':
        return <AdminTaskPage />;
      case 'developer':
        return <DeveloperTaskPage />;
      case 'client':
        return <ClientTaskPage />;
      default:
        return <PageNotFound/>;
    }
  };

  return (
    <div className="task-management">
      {renderTaskPage()}
    </div>
  );
};

export default TaskManagement;