import React from 'react';
import { Link } from 'react-router-dom';
import { FaHome, FaArrowLeft, FaSearch, FaExclamationTriangle } from 'react-icons/fa';
import styles from './PageNotFound.module.css';

const PageNotFound: React.FC = () => {
  return (
    <div className={styles.pageNotFound}>
      <div className={styles.container}>
        <div className={styles.content}>
          {/* Animated 404 Number */}
          <div className={styles.errorNumber}>
            <span className={styles.number}>4</span>
            <span className={styles.zero}>
              <FaExclamationTriangle className={styles.exclamation} />
            </span>
            <span className={styles.number}>4</span>
          </div>

          {/* Main Message */}
          <div className={styles.message}>
            <h1>Page Not Found</h1>
            <p>
              Oops! The page you're looking for seems to have wandered off into the digital wilderness. 
              Don't worry, even the best explorers sometimes take wrong turns.
            </p>
          </div>

          {/* Action Buttons */}
          <div className={styles.actions}>
            <Link to="/dashboard" className={styles.btnPrimary}>
              <FaHome /> Back to Dashboard
            </Link>
            <button onClick={() => window.history.back()} className={styles.btnSecondary}>
              <FaArrowLeft /> Go Back
            </button>
          </div>

          {/* Helpful Suggestions */}
          <div className={styles.suggestions}>
            <h3>While you're here, you might want to:</h3>
            <ul>
              <li>Check the URL for typos</li>
              <li>Visit our homepage</li>
              <li>Contact support if you believe this is an error</li>
              <li>Explore other sections of the application</li>
            </ul>
          </div>

          {/* Decorative Elements */}
          <div className={styles.decorative}>
            <div className={styles.circle}></div>
            <div className={styles.circle}></div>
            <div className={styles.circle}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PageNotFound;