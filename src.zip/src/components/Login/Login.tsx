import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import type { RootState } from '../../store/store';
import { loginUser } from '../../store/slices/authSlice';
import { FaEnvelope, FaLock, FaSignInAlt, FaExclamationTriangle } from 'react-icons/fa';
import styles from './Login.module.css';

const Login: React.FC = () => {
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading, isAuthenticated, error: authError } = useSelector((state: RootState) => state.auth);

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/dashboard');
    }
  }, [isAuthenticated, navigate]);

  // Handle auth errors from Redux store
  useEffect(() => {
    if (authError) {
      setError(authError);
      setIsSubmitting(false);
    }
  }, [authError]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    
    if (!credentials.email || !credentials.password) {
      setError('Please enter both email and password');
      setIsSubmitting(false);
      return;
    }

    // Basic email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(credentials.email)) {
      setError('Please enter a valid email address');
      setIsSubmitting(false);
      return;
    }

    try {
      const result = await dispatch(loginUser(credentials) as any);
      
      if (result.error) {
        return;
      }
    } catch (error) {
      console.error('Login failed:', error);
      setError('An unexpected error occurred. Please try again.');
      setIsSubmitting(false);
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setCredentials({ ...credentials, [field]: value });
    // Clear error when user starts typing
    if (error) {
      setError('');
    }
  };

  // Show loading if checking authentication or logging in
  if (loading && !isSubmitting) {
    return (
      <div className={styles.loginContainer}>
        <div className={styles.loginCard}>
          <div className={styles.loading}>
            <div className={styles.spinner}></div>
            Loading...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={styles.loginContainer}>
      <div className={styles.loginCard}>
        <div className={styles.loginHeader}>
          <h1 className={styles.loginTitle}>T&T VisionDesk</h1>
          <p className={styles.loginSubtitle}>Progress tracking made easy</p>
        </div>
        
        {error && (
          <div className={styles.errorMessage}>
            <FaExclamationTriangle className={styles.errorIcon} />
            <div className={styles.errorContent}>
              <strong>Login Failed </strong>
              <span>{error}</span>
            </div>
            <button 
              onClick={() => setError('')} 
              className={styles.errorClose}
              aria-label="Close error message"
            >
              ×
            </button>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className={styles.loginForm}>
          <div className={styles.formGroup}>
            <FaEnvelope className={styles.inputIcon} />
            <input
              type="email"
              placeholder="Email address"
              value={credentials.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              required
              className={styles.formInput}
              disabled={isSubmitting}
              autoComplete="email"
            />
          </div>
          
          <div className={styles.formGroup}>
            <FaLock className={styles.inputIcon} />
            <input
              type="password"
              placeholder="Password"
              value={credentials.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              required
              className={styles.formInput}
              disabled={isSubmitting}
              autoComplete="current-password"
            />
          </div>
          
          <button 
            type="submit" 
            disabled={isSubmitting} 
            className={`${styles.loginBtn} ${isSubmitting ? styles.loading : ''}`}
          >
            {isSubmitting ? (
              <>
                <div className={styles.btnSpinner}></div>
                Signing In...
              </>
            ) : (
              <>
                <FaSignInAlt className={styles.btnIcon} />
                Sign In
              </>
            )}
          </button>
        </form>

        <div className={styles.demoAccounts}>
          <h3>Demo Accounts:</h3>
          <div className={styles.demoAccountItem}>
            <strong>Admin:</strong> admin@visiondesk.com / password
          </div>
          <div className={styles.demoAccountItem}>
            <strong>Manager:</strong> manager@visiondesk.com / password
          </div>
          <div className={styles.demoAccountItem}>
            <strong>Employee:</strong> dev@visiondesk.com / password
          </div>
          <div className={styles.demoAccountItem}>
            <strong>Client:</strong> client@company.com / password
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;